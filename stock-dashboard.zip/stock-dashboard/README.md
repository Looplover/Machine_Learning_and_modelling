# 📈 Multicloud Stock Market Dashboard

### Description
A full-stack dashboard using:
- 🧠 AWS SageMaker for stock price prediction
- 📊 Yahoo Finance for historical data
- 🖥️ Flask backend (hosted on Azure App Service)
- 🌐 Bootstrap frontend (hosted on Azure Static Web App)

---

### 🏗 How to Deploy

#### 🔙 Backend (Flask)
1. Go to Azure Portal → Create a **Web App (Python 3.10, Linux)**
2. Connect to GitHub repo
3. Set these environment variables:
   - `SAGEMAKER_ENDPOINT` = your SageMaker endpoint name
4. Azure will install dependencies and run your Flask API

#### 🌐 Frontend
1. Push `frontend/` folder to GitHub
2. Go to Azure Portal → Create **Static Web App**
3. Set source to `frontend` folder
4. Deploy and enjoy 🚀

---

### 🧠 Model
Train a Linear Regression model on stock prices using `yfinance` and deploy to SageMaker.

---

### 🔧 Tech Stack
- AWS SageMaker
- Flask + Gunicorn
- Bootstrap
- Azure App Service / Static Web App

---

### 💡 Future Improvements
- Login system
- Graphs (Plotly)
- Advanced prediction models
