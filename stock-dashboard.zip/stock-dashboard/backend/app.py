from flask import Flask, jsonify, request
from flask_cors import CORS
import yfinance as yf
from datetime import datetime, timedelta
import pandas as pd

app = Flask(__name__)
CORS(app)

@app.route('/stock/<symbol>', methods=['GET'])
def get_stock_data(symbol):
    try:
        days = request.args.get('days', 7, int)
        period = f"{days}d"

        data = yf.download(symbol, period=period, interval="1d", group_by='ticker')

        if data.empty:
            return jsonify({"error": "No data found for symbol"}), 404

        closes = data[symbol]['Close'].tolist()
        opens = data[symbol]['Open'].tolist()
        high = data[symbol]['High'].tolist()
        low = data[symbol]['Low'].tolist()
        dates = data[symbol].index.strftime('%Y-%m-%d').tolist()

        latest_close = closes[-1]
        predicted_close = latest_close + 1.0
        last_date = data[symbol].index[-1]
        tomorrow_date = (last_date + timedelta(days=1)).strftime('%Y-%m-%d')

        return jsonify({
            "symbol": symbol.upper(),
            "historical": {
                "dates": dates,
                "closes": [round(x, 2) for x in closes],
                "opens": [round(x, 2) for x in opens],
                "high": [round(x, 2) for x in high],
                "low": [round(x, 2) for x in low]
            },
            "latest_close": round(latest_close, 2),
            "prediction": {
                "date": tomorrow_date,
                "close": round(predicted_close, 2)
            }
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)