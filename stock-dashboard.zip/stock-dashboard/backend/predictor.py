import boto3
import json
import os

# Make sure AWS credentials are available in environment
runtime = boto3.client('sagemaker-runtime', region_name='us-east-1')

def predict_price(close_price):
    response = runtime.invoke_endpoint(
        EndpointName=os.getenv("SAGEMAKER_ENDPOINT"),
        ContentType='application/json',
        Body=json.dumps([[close_price]])
    )
    result = json.loads(response['Body'].read().decode())
    return result[0]
