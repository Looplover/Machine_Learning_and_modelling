function getStockData() {
  const symbol = document.getElementById('symbol').value.toUpperCase();
  const days = document.getElementById('days').value;
  const resultDiv = document.getElementById('result');

  const closeCtx = document.getElementById('stockChart').getContext('2d');
  const openCtx = document.getElementById('openChart').getContext('2d');
  const highCtx = document.getElementById('highChart').getContext('2d');
  const lowCtx = document.getElementById('lowChart').getContext('2d');

  if (!symbol) {
    resultDiv.innerHTML = `<p class="text-danger">Please enter a stock symbol.</p>`;
    return;
  }

  fetch(`http://127.0.0.1:5000/stock/${symbol}?days=${days}`)
    .then(res => res.json())
    .then(data => {
      if (data.error) {
        resultDiv.innerHTML = `<p class="text-danger">${data.error}</p>`;
        return;
      }

      resultDiv.innerHTML = `
        <h3>${data.symbol}</h3>
        <p><strong>Latest Close:</strong> $${data.latest_close.toFixed(2)}</p>
        <p><strong>Predicted Close:</strong> $${data.prediction.close.toFixed(2)}</p>
      `;

      if (window.chartInstance) window.chartInstance.destroy();
      if (window.openInstance) window.openInstance.destroy();
      if (window.highInstance) window.highInstance.destroy();
      if (window.lowInstance) window.lowInstance.destroy();

      const labels = data.historical.dates;

      window.chartInstance = new Chart(closeCtx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: `${data.symbol} Close Price`,
            data: data.historical.closes,
            backgroundColor: 'rgba(13, 110, 253, 0.1)',
            borderColor: '#0d6efd',
            borderWidth: 2,
            pointBackgroundColor: '#0d6efd',
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: true } },
          scales: { y: { beginAtZero: false } }
        }
      });

      window.openInstance = new Chart(openCtx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: `${data.symbol} Open Price`,
            data: data.historical.opens,
            backgroundColor: 'rgba(25, 135, 84, 0.1)',
            borderColor: '#198754',
            borderWidth: 2,
            pointBackgroundColor: '#198754',
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: true } },
          scales: { y: { beginAtZero: false } }
        }
      });

      window.highInstance = new Chart(highCtx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: `${data.symbol} High`,
            data: data.historical.high,
            backgroundColor: 'rgba(255, 193, 7, 0.1)',
            borderColor: '#ffc107',
            borderWidth: 2,
            pointBackgroundColor: '#ffc107',
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: true } },
          scales: { y: { beginAtZero: false } }
        }
      });

      window.lowInstance = new Chart(lowCtx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: `${data.symbol} Low`,
            data: data.historical.low,
            backgroundColor: 'rgba(255, 50, 7, 0.1)',
            borderColor: '#ff0000',
            borderWidth: 2,
            pointBackgroundColor: '#ff0000',
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: true } },
          scales: { y: { beginAtZero: false } }
        }
      });
    })
    .catch(err => {
      resultDiv.innerHTML = `<p class="text-danger">Error fetching data.</p>`;
      console.error(err);
    });
}
